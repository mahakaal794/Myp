const getcode = () => {
    const randomNumber = Math.floor(Math.random() * 16777215);
    const randomcode = "#" + randomNumber.toString(16);
    console.log(randomcode); // Assuming you want to log the generated code

    // Additional actions with the code if needed
    document.body.style.backgroundColor = randomcode;
    document.querySelector('h1').innerText = randomcode;
};

document.querySelector("#btn").addEventListener('click', getcode);

// If you want to generate a code initially, you can call getcode here
// getcode();

getcode();